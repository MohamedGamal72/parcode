<template>
  <div class="text-center mt-5">
    <h2 class="mb-3">
      هذه الصفحة غير موجودة
    </h2>
    <p>خطأ 404</p>
  </div>
</template>

<script>
  export default {
    components: {},
    data () {
      return {}
    },
    computed: {},
    created () {

    },
    methods: {},
  }
</script>
