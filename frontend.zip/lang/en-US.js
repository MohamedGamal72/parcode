export default async (context, locale) => {
  await resolve({
    welcome: 'Welcomxxe'
  })
}
